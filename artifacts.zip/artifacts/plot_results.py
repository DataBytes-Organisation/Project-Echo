import pandas as pd, matplotlib.pyplot as plt

df = pd.read_csv("artifacts/summary_results.csv")
plt.figure(figsize=(8,4)); plt.bar(df["Model"], df["Accuracy"]); plt.title("Accuracy by Model")
plt.ylabel("Accuracy"); plt.tight_layout(); plt.savefig("artifacts/accuracy_bar.png", dpi=160); plt.close()

plt.figure(figsize=(8,4)); plt.bar(df["Model"], df["F1 Macro"]); plt.title("F1 Macro by Model")
plt.ylabel("F1 Macro"); plt.tight_layout(); plt.savefig("artifacts/f1_macro_bar.png", dpi=160); plt.close()

print("Saved artifacts/accuracy_bar.png and artifacts/f1_macro_bar.png")
