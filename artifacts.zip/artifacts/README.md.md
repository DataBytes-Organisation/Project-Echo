\# Audio Benchmark CLI



Run classical baselines (Logistic Regression, SVM–RBF) on pooled Mel-spectrogram features and save reports/plots to `./artifacts`.  

This is a CLI refactor of the sprint-1 notebook so anyone can clone → install → run.



---



\## Repo layout



capstone-bench/

├─ main.py # entry point (parses args \& runs selected models)

├─ bench\_helpers.py # data loading, feature pooling, training, logging

├─ plot\_results.py # optional: bar charts from summary\_results.csv

├─ run\_bench.bat # optional 1-click (Windows)

├─ run.sh # optional 1-click (Mac/Linux)

├─ requirements.txt

├─ .gitignore

└─ artifacts/ # generated outputs (not committed)





---



\## Install (pip + virtual env)

```bash

\# in repo root

python -m venv .venv

\# Windows:

.venv\\Scripts\\activate

\# macOS/Linux:

\# source .venv/bin/activate



pip install -r requirements.txt





### Data layout (expected)



<data\_root>/

&nbsp; bucket1/

&nbsp;   Class\_A/  file1.wav, file2.wav, ...

&nbsp;   Class\_B/  ...

&nbsp; bucket2/    (optional)

&nbsp; ...





### Run

### Windows (example):





python main.py ^

&nbsp; --data\_root "C:\\Users\\Mahsa\\OneDrive\\Documents\\T2-2025\\CapstonProject-SIT782\\data" ^

&nbsp; --buckets bucket1 ^

&nbsp; --model\_name logreg,svm

### 

### macOS/Linux:



python main.py --data\_root "/path/to/data" --buckets bucket1 --model\_name logreg,svm





### Outputs (in ./artifacts)



* summary\_results.csv — overall metrics table (Accuracy, Balanced Acc, Macro/Micro F1, Top-3 Acc)



* logreg\_baseline\_class\_report.csv \& svm\_rbf\_class\_report.csv — per-class precision/recall/F1



* logreg\_baseline\_confusion.png \& svm\_rbf\_confusion.png — normalized confusion matrices



### Optional bar charts:



python plot\_results.py

\# creates artifacts/accuracy\_bar.png and artifacts/f1\_macro\_bar.png





### One-click runners (optional)



Windows — edit the data path inside run\_bench.bat, then double-click:



@echo off

set "DATA=C:\\Users\\Mahsa\\OneDrive\\Documents\\T2-2025\\CapstonProject-SIT782\\data"

python main.py --data\_root "%DATA%" --buckets bucket1 --model\_name logreg,svm

pause



macOS/Linux:



chmod +x run.sh

./run.sh "/path/to/data"



### Extend — add another model



1. Implement run\_<name>(X\_train, X\_test, y\_train, y\_test, class\_names, prefix, save\_dir) in bench\_helpers.py (copy run\_logreg as a template).



2\.Register it in main.py:



dispatch = {

&nbsp;   "logreg": run\_logreg,

&nbsp;   "svm": run\_svm\_rbf,

&nbsp;   "mynew": run\_mynew\_model,

}



3.Run with --model\_name mynew.



### Troubleshooting



* **CSV locked on Windows:** if Excel is open on an artifact CSV, you may see a permission error. Close Excel and re-run (or delete the file).



* **soundfile/librosa errors:** ensure pip install soundfile completed successfully.



* **Few samples per class:** classes with <2 files are dropped to keep stratified split stable.





Your original content already covered install, run, outputs, and troubleshooting—this just improves formatting and Markdown rendering. :contentReference\[oaicite:4]{index=4} :contentReference\[oaicite:5]{index=5} :contentReference\[oaicite:6]{index=6} :contentReference\[oaicite:7]{index=7}



If you want, I can also generate a tiny `requirements.txt` and `.gitignore` to include in the repo.



