# bench_helpers.py
# Minimal helpers extracted from your notebook to run classic baselines (LogReg / SVM)
# and log results as artifacts. Safe to use on Windows/Anaconda.

from pathlib import Path
import hashlib
import numpy as np
import pandas as pd
import librosa

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score, f1_score, balanced_accuracy_score,
    confusion_matrix, classification_report
)

import matplotlib.pyplot as plt

# ----------------------------- Settings -----------------------------
TARGET_SR = 16000
N_MELS = 128
HOP = 512
FMIN = 40
FMAX = TARGET_SR // 2
VALID_EXTS = {".wav", ".flac", ".mp3", ".ogg", ".m4a"}
RANDOM_STATE = 42


# ----------------------------- Data scan -----------------------------
def scan_audio(root: str, buckets):
    """
    Walks folders like <root>/<bucket>/<species>/*.wav and returns a DataFrame
    with columns: path, label, bucket
    """
    rows = []
    root = Path(root)
    for b in buckets:
        top = root / b
        if not top.exists():
            print(f"⚠️ Missing bucket: {top}")
            continue
        for species_dir in sorted([d for d in top.iterdir() if d.is_dir()]):
            label = species_dir.name
            for p in species_dir.rglob("*"):
                if p.is_file() and p.suffix.lower() in VALID_EXTS:
                    rows.append({"path": str(p), "label": label, "bucket": b})
    return pd.DataFrame(rows)


def prepare_dataset(
    data_root,
    buckets,
    test_size=0.2,
    seed=RANDOM_STATE,
    artifacts_dir="./artifacts"
):
    """
    - Loads file list
    - Drops labels with <2 files (can’t stratify those)
    - Picks a test fraction large enough to have >= 1 item per class in test
      (otherwise falls back to random split without stratify)
    - Saves class names to artifacts
    """
    df = scan_audio(data_root, buckets)
    if df.empty:
        raise RuntimeError(f"No audio files found under {data_root} for buckets {buckets}")

    # Drop classes that cannot be stratified (need >=2 files)
    vc = df["label"].value_counts()
    rare = vc[vc < 2]
    if len(rare) > 0:
        print(f"⚠️  Dropping {len(rare)} labels with <2 files (cannot stratify).")
        df = df[df["label"].isin(vc[vc >= 2].index)].reset_index(drop=True)

    if df.empty:
        raise RuntimeError("All labels had <2 files after filtering; add more data or combine buckets.")

    # Encode labels
    le = LabelEncoder()
    y = le.fit_transform(df["label"])
    X = df["path"].tolist()

    N = len(X)
    K = len(le.classes_)

    # Minimum fraction so test has at least K items
    min_frac = (K + 1) / max(N, 1)

    # Choose a safe test size
    TEST_SIZE = max(float(test_size), min_frac, 0.2)   # prefer >=20%
    TEST_SIZE = min(TEST_SIZE, 0.8)                    # leave some for training

    stratify_vec = y
    if TEST_SIZE * N < K:
        # Even 80% isn't enough → give up on stratification
        print("⚠️  Not enough items per class for stratified split. "
              "Falling back to random split (no stratify). Consider combining buckets.")
        TEST_SIZE = max(float(test_size), 0.2)
        stratify_vec = None

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=seed, stratify=stratify_vec
    )

    Path(artifacts_dir).mkdir(exist_ok=True, parents=True)
    pd.Series(le.classes_).to_csv(Path(artifacts_dir) / "class_names.csv", index=False, header=False)
    return X_train, X_test, y_train, y_test, list(le.classes_)


# ----------------------------- Features (Mel + pooling) -----------------------------
def _cache_path(artifacts_dir, audio_path):
    h = hashlib.md5(audio_path.encode("utf-8")).hexdigest()[:16]
    return Path(artifacts_dir) / f"mel_{h}.npy"


def load_mel_cached(audio_path: str, artifacts_dir: str):
    """
    Loads (or computes+stores) Mel-spectrogram for a single file.
    """
    cpath = _cache_path(artifacts_dir, audio_path)
    if cpath.exists():
        return np.load(cpath)

    y, sr = librosa.load(audio_path, sr=TARGET_SR, mono=True)
    M = librosa.feature.melspectrogram(
        y=y, sr=sr, n_mels=N_MELS, hop_length=HOP, fmin=FMIN, fmax=FMAX
    )
    M = M.astype(np.float32)
    np.save(cpath, M)
    return M


def pool_stats_over_time(mel: np.ndarray) -> np.ndarray:
    """
    Pooled features: mean + std + max over time → shape [3 * n_mels], float32, contiguous.
    """
    v = np.concatenate([mel.mean(1), mel.std(1), mel.max(1)], axis=0).astype(np.float32)
    return np.ascontiguousarray(v)


def pooled_features(paths, artifacts_dir):
    feats = [pool_stats_over_time(load_mel_cached(p, artifacts_dir)) for p in paths]
    return np.stack(feats, axis=0).astype(np.float32)


# ----------------------------- Evaluation & logging -----------------------------
def topk_accuracy(y_true, y_proba, k=3):
    if y_proba is None:
        return float("nan")
    topk = np.argsort(y_proba, axis=1)[:, -k:]
    y_true = np.asarray(y_true).reshape(-1, 1)
    return float((topk == y_true).any(axis=1).mean())


def evaluate_and_log(y_true, y_pred, y_proba, class_names, prefix, save_dir="./artifacts"):
    """
    Computes metrics, saves per-class classification report and confusion matrix.
    """
    save_dir = Path(save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    metrics = {
        "acc": accuracy_score(y_true, y_pred),
        "balanced_acc": balanced_accuracy_score(y_true, y_pred),
        "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_micro": f1_score(y_true, y_pred, average="micro", zero_division=0),
        "top3_acc": topk_accuracy(y_true, y_proba, 3),
    }

    # Per-class report
    report_df = pd.DataFrame(
        classification_report(
            y_true, y_pred, target_names=class_names, output_dict=True, zero_division=0
        )
    ).T
    report_df.to_csv(save_dir / f"{prefix}_class_report.csv", index=True)

    # Row-normalized confusion
    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(class_names))))
    with np.errstate(invalid="ignore", divide="ignore"):
        cm_norm = cm / cm.sum(axis=1, keepdims=True)
        cm_norm[np.isnan(cm_norm)] = 0.0

    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(cm_norm, aspect="auto")
    ax.set_title(f"Confusion (normalized) — {prefix}")
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")

    # tick thinning for readability
    step = max(1, len(class_names) // 20)
    ticks = list(range(0, len(class_names), step))
    ax.set_xticks(ticks); ax.set_yticks(ticks)
    ax.set_xticklabels([class_names[i] for i in ticks], rotation=45, ha="right")
    ax.set_yticklabels([class_names[i] for i in ticks])

    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(save_dir / f"{prefix}_confusion.png", dpi=160)
    plt.close(fig)

    return metrics


def write_summary_table(rows, out_csv):
    df = pd.DataFrame(rows)
    df.to_csv(out_csv, index=False)
    print("\nSummary:")
    print(df)
    print(f"\nSaved: {out_csv}")


# ----------------------------- Models -----------------------------
def run_logreg(X_train, X_test, y_train, y_test, class_names, artifacts_dir):
    """
    Logistic Regression baseline on pooled features.
    """
    Xtr = pooled_features(X_train, artifacts_dir)
    scaler = StandardScaler().fit(Xtr)
    Xtr = scaler.transform(Xtr)

    clf = LogisticRegression(
        max_iter=2000,
        solver="lbfgs",
        multi_class="multinomial",
        n_jobs=None,     # accepted parameter; not used by lbfgs but harmless
        verbose=0
    )
    clf.fit(Xtr, y_train)

    Xt = scaler.transform(pooled_features(X_test, artifacts_dir))
    try:
        proba = clf.predict_proba(Xt)
    except Exception:
        # some sklearn builds might not expose predict_proba if not fitted that way
        proba = None
    preds = clf.predict(Xt) if proba is None else proba.argmax(1)

    m = evaluate_and_log(y_test, preds, proba, class_names, prefix="logreg_baseline", save_dir=artifacts_dir)
    return {
        "Model": "Logistic Regression",
        "Accuracy": round(m["acc"], 4),
        "Balanced Acc": round(m["balanced_acc"], 4),
        "F1 Macro": round(m["f1_macro"], 4),
        "F1 Micro": round(m["f1_micro"], 4),
        "Top-3 Acc": round(m["top3_acc"], 4),
    }


def run_svm_rbf(X_train, X_test, y_train, y_test, class_names, artifacts_dir, C=10.0, gamma="scale"):
    """
    SVM with RBF kernel on pooled features.
    """
    Xtr = pooled_features(X_train, artifacts_dir)
    scaler = StandardScaler().fit(Xtr)
    Xtr = scaler.transform(Xtr)

    svm = SVC(kernel="rbf", C=C, gamma=gamma, probability=True, class_weight="balanced")
    svm.fit(Xtr, y_train)

    Xt = scaler.transform(pooled_features(X_test, artifacts_dir))
    proba = svm.predict_proba(Xt)
    preds = proba.argmax(1)

    m = evaluate_and_log(y_test, preds, proba, class_names, prefix="svm_rbf", save_dir=artifacts_dir)
    return {
        "Model": "SVM (RBF)",
        "Accuracy": round(m["acc"], 4),
        "Balanced Acc": round(m["balanced_acc"], 4),
        "F1 Macro": round(m["f1_macro"], 4),
        "F1 Micro": round(m["f1_micro"], 4),
        "Top-3 Acc": round(m["top3_acc"], 4),
    }
