# main.py
"""
Run from terminal, e.g.:
  python main.py --data_root "C:/path/to/data" --buckets bucket1 --model_name logreg,svm

Outputs go to ./artifacts by default.
"""
import argparse
from pathlib import Path
from bench_helpers import prepare_dataset, run_logreg, run_svm_rbf, write_summary_table

def parse_args():
    p = argparse.ArgumentParser(description="Audio benchmark (LogReg/SVM)")
    p.add_argument("--data_root", required=True, help="Root folder with your buckets/species folders")
    p.add_argument("--buckets", default="bucket1", help="Comma list of bucket names (e.g., bucket1,bucket2)")
    p.add_argument("--model_name", default="logreg", help="Comma list: logreg,svm")
    p.add_argument("--test_size", type=float, default=0.2, help="Fraction for test split")
    p.add_argument("--seed", type=int, default=42, help="Random seed")
    p.add_argument("--artifacts_dir", default="./artifacts", help="Where to save results")
    return p.parse_args()

def main():
    args = parse_args()
    artifacts = Path(args.artifacts_dir); artifacts.mkdir(parents=True, exist_ok=True)
    model_list = [m.strip().lower() for m in args.model_name.split(",") if m.strip()]

    X_train, X_test, y_train, y_test, class_names = prepare_dataset(
        data_root=args.data_root,
        buckets=args.buckets.split(","),
        test_size=args.test_size,
        seed=args.seed,
        artifacts_dir=str(artifacts),
    )

    rows = []
    for name in model_list:
        if name == "logreg":
            print("\n=== Running Logistic Regression ===")
            rows.append(run_logreg(X_train, X_test, y_train, y_test, class_names, str(artifacts)))
        elif name == "svm":
            print("\n=== Running SVM (RBF) ===")
            rows.append(run_svm_rbf(X_train, X_test, y_train, y_test, class_names, str(artifacts)))
        else:
            print(f"⚠️ Unknown model '{name}' (supported: logreg, svm)")

    if rows:
        out_csv = artifacts / "summary_results.csv"
        write_summary_table(rows, out_csv)

if __name__ == "__main__":
    main()
