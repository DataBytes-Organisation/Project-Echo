from .myfunctions import plot_waveform, plot_mel_spectrogram
